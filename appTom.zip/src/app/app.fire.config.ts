export const FIREBASE_CONFIG = {

  

    apiKey: "AIzaSyA_82taJqfhMS27xge0JJE29_3xhDGxNDw",
    authDomain: "stockwatcher-f0010.firebaseapp.com",
    databaseURL: "https://stockwatcher-f0010.firebaseio.com",
    projectId: "stockwatcher-f0010",
    storageBucket: "stockwatcher-f0010.appspot.com",
    messagingSenderId: "235999219307"
  };
    
 
  
